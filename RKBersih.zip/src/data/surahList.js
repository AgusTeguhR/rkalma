export const surahList = [
  { name: "Surah Al-Kahfi", arab: "الكهف" },
  { name: "Surah Yasin", arab: "يس" },
  { name: "Surah Al-Waqi'ah", arab: "الواقعة" },
  { name: "Surah Al-Mulk", arab: "الملك" },
];
