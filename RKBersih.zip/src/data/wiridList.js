export const wiridList = [
  { name: "Wirid Sholat" },
  { name: "Wirdul Lathif" },
  { name: "Rathibul Haddad" },
  { name: "Rathibul Atthos" },
  { name: "Hizib Bahar" },
  { name: "Tarhim Sebelum Subuh" },
  {
    name: "Istigfar Menjelang Maghrib",
  },
];
