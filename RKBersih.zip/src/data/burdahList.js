export const burdahList=[
    {name: "Pasal 1"},
    {name: "Pasal 2"},
    {name: "Pasal 3"},
    {name: "Pasal 4"},
    {name: "Pasal 5"},
    {name: "Pasal 6"},
    {name: "Pasal 7"},
    {name: "Pasal 8"},
    {name: "Pasal 9"},
    {name: "Pasal 10"},
]