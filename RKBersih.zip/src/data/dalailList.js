export const dalailList=[
    {name: "Muqaddimah Dalail"},
    {name: "Senin Awal"},
    {name: "Senin Akhir"},
    {name: "Selasa"},
    {name: "Rabu"},
    {name: "Kamis"},
    {name: "Jum'at"},
    {name: "Sabtu"},
    {name: "Ahad"},
    {name: "Doa Khatam Dalail"},
]